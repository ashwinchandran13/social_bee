A Pen created at CodePen.io. You can find this one at https://codepen.io/ctrlaltdev/pen/XPZNNP.

 react component that creates a comment section - but will not send the comments to a sever / database.
only the comments will never be visible to other users, it will stay in local storage and only be displayed to its author.
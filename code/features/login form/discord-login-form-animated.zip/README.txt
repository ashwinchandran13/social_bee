A Pen created at CodePen.io. You can find this one at https://codepen.io/ashwin-chandran/pen/vMjzbM.

 This is the same as my other discord login form. But with some nice animations for when you load the page.
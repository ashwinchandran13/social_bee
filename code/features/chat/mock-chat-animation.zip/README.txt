A Pen created at CodePen.io. You can find this one at https://codepen.io/ashwin-chandran/pen/JVvaVB.

 Based on Discord/Slack. Complete with a profile image, username with color, timestamps, multiple lines of text with the last line randomly stopping, image or rich body, a sweet animation, and also an input.
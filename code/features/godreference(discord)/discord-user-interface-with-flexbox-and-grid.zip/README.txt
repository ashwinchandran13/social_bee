A Pen created at CodePen.io. You can find this one at https://codepen.io/ashwin-chandran/pen/ZZoMgX.

 A basic mock-up of Discord's user interface with flexbox and grid. I will try to update it over time and add more interactivity and design.
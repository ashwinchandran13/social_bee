A Pen created at CodePen.io. You can find this one at https://codepen.io/radibit/pen/bpRpPz.

 Notification icon animation. Works best under Chrome / IE due to the `transform-origin` property.
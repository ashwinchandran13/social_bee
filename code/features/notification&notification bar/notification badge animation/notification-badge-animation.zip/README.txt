A Pen created at CodePen.io. You can find this one at https://codepen.io/AlikinVV/pen/wOyGNJ.

 <p style="text-align:center"><img width="58%" src="https://cdn.dribbble.com/users/1773016/screenshots/6177695/1.gif"></p>
<p>Inspired by this <a href="https://dribbble.com/shots/6169148-Notification-Badge">Dribbble Shot</a>.</p>